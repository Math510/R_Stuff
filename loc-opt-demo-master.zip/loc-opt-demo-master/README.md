loc-opt-demo
============

Location Optimization in R Demo

Presented at:

* [INFORMS-MD](http://www.meetup.com/INFORMS-Maryland/events/138220312/) 
  Oct. 23, 2013
* [Statistical Programming DC](http://www.meetup.com/stats-prog-dc/events/138396932/),
  Oct. 24, 2013
  
Introductory blog post: [How to Put Your Meetup on the Map -- Literally](http://datacommunitydc.org/blog/2013/10/how-to-put-your-meetup-on-the-map-literally/)

